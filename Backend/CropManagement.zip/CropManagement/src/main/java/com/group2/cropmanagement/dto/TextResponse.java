package com.group2.cropmanagement.dto;

public record TextResponse(String text) {
}

