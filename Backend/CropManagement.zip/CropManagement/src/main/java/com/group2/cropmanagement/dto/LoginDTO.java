package com.group2.cropmanagement.dto;

import lombok.Data;

@Data
public class LoginDTO {
    private String email;

    private String password;
}
