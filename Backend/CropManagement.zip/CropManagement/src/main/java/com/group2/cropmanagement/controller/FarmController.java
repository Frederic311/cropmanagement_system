package com.group2.cropmanagement.controller;

import org.springframework.stereotype.Controller;

@Controller
public class FarmController {
}
