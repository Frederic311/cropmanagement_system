package com.group2.cropmanagement.dto;

import lombok.Data;

@Data
public class FarmSearchDTO {
    private Long id;
    private String name;
    private String description;
}
