package com.group2.cropmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CropManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
